#include "light.h"
#include "phong_shader.h"
#include "ray.h"
#include "render_world.h"
#include "object.h"

vec3 Phong_Shader::
Shade_Surface(const Ray& ray,const vec3& intersection_point,
    const vec3& normal,int recursion_depth) const
{
    vec3 color;
    vec3 ambient = color_ambient * world.ambient_color * world.ambient_intensity; //Get the ambient value
    vec3 diffuse;
    vec3 specular;

    Ray tempRay;
    Hit hit;
    vec3 hitObjects;
    vec3 tempLight;

    for (unsigned i = 0; i < world.lights.size(); i++) {
      //Creates a ray by using the current light position and the intersection point
      tempLight = world.lights.at(i)->position - intersection_point;
      tempRay = Ray(intersection_point, tempLight);
      //Tracks if this ray hits any objects
      hit = world.Closest_Intersection(tempRay);
      hitObjects = tempRay.Point(hit.dist) - intersection_point;

      //Make a variable r and a variable LVal which corresponds with L_d and L_s
      vec3 r = (-tempLight + 2 * dot(tempLight, normal) * normal).normalized();
      vec3 LVal = world.lights.at(i)->Emitted_Light(tempLight);

      if (!world.enable_shadows || !hit.object || hitObjects.magnitude() > tempLight.magnitude()) {
        //Get the max for both the diffuse reflection (max(n dot l, 0)) and specular reflection (max(cos(phi), 0))
        double diffuseMax = std::max(dot(normal, tempLight.normalized()),0.0);
        double specularMax = std::pow(std::max(dot(r, -(ray.direction)), 0.0), specular_power);

        //Calculate the value of diffuse and specular for light.at(i) and add them to the total diffuse/specular value
        diffuse += color_diffuse * LVal * diffuseMax;
        specular += color_specular * LVal * specularMax;
      }
    }

    color = ambient + diffuse + specular;

    return color;
}
